const foods = ["watermelon", "peach", "apple", "tomato", "grape"];

const six = foods.filter((foods) => foods.length > 6);

console.log(six);
