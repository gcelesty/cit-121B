const steps = ["one", "two", "three"];

const stepsHtml = steps.map(function (step) {
  return `<li>${step}</li>`;
});

document.getElementById("myList").innerHTML = stepsHtml.join();
